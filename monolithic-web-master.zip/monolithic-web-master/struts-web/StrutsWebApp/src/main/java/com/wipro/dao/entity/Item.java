/**
 * 
 */
package com.wipro.dao.entity;

/**
 * @author PA20063329
 *
 */
public class Item {

}
